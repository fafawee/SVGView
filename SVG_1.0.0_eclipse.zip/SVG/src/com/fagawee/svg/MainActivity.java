package com.fagawee.svg;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import com.fagawee.svg.libs.SvgView;
import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.graphics.Color;
import android.graphics.Paint.Style;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import android.os.Build;

public class MainActivity extends Activity {
	public static final String fc="M41 40L236 235L427 45C427 45 523 -72 751 39L556 237L747 431C747 431 854 527 750 747L551 556L353 749C353 749 245 853 43 746L235 554L41 353C41 353 -60 253 41 40Z";
	public static final String fc1="M27 29L148 150L272 28C272 28 338 -33 468 28L348 150L474 280C474 280 527 350 469 469L348 350L224 468C224 468 154 536 26 470L148 348L30 230C30 230 -34 174 27 29Z";
	public static final String svgs="M120 8C120 8 114 24 88 10C88 10 55 -1 29 17C3 35 4 60 7 76C10 92 20 98 26 102C26 102 52 118 69 125C86 132 108 148 112 158C112 158 126 192 98 214C98 214 78 234 38 212C38 212 21 204 10 165C10 165 0 168 2 168L14 230L24 222C24 222 32 218 46 226C62 236 110 236 124 202C124 202 144 170 125 141C125 141 114 122 88 111C62 100 23 82 23 68C23 56 20 14 66 16C66 16 101 9 118 62L125 60L120 8Z"
									+"M165 85L218 85L218 93C218 93 199 90 204 105C209 120 236.75 200 236.75 200L271 107C271 107 276 93 258 93L258 85L302 85L302 93C302 93 292 92 289 96C289 96 284 100 281 106L236 230L229 230L185 103C185 103 181 93 173 93L165 93C165 93 166 85 165 85Z"
									+"M430 94C430 94 402 68 362 93C362 93 345 104 344 130C344 130 343 151 362 166C362 166 363 168 360 169C358 170 348 176 346 184C345 192 343 199 360 208C360 208 364 210 359 211C354 212 342 220 339 228C337 234 330 252 348 264C366 276 386 282 428 274C428 274 459 266 461 240C463 215 449 211 447 209C446 208 440 204 398 198C356 193 367 194 366 194C364 193 352 182 370 171C370 171 371 170 374 172C376 173 386 178 396 177C406 176 430 176 442 148C454 120 436 104 436 100C436 100 448 88 453 100C453 100 456 110 467 102C467 102 472 99 469 90C466 80 458 81 456 81C456 81 446 84 440 88C435 92 430 94 430 94ZM394 91M797 93M803 404M761 236M382 167C382 167 409.5 177.5 422.5 156.75C422.5 156.75 431 146.5 426 114C426 114 425 96 398 91C398 91 386 88 371 100C371 100 351 127 369 156C369 156 374 163 379 166C384 168 382 167 382 167ZM370 212C370 212 422.75 216 434.75 222C447 228 452 253 431 263C410 273 363 276 352 248C352 248 346 225 367 214L370 212Z";
	public static final String fllower="M212.125 264.875C212.125 264.875 41 318 16 239C16 239 18 95 119 142C119 142 177.5 165.25 225.5 227.25C225.5 227.25 128 83 188 48C248 13 309 47 319 61C319 61 353.375 111.75 268.375 226.75C268.375 226.75 390 95 439 141C439 141 497 186 473 254C473 254 443.75 308.75 280.75 264.5C279.9055 264.2708 431.5 325 428 383C428 383 424 442 342 459C260 476 246.625 290.875 246.625 287.875C246.625 284.875 231 455 170 458C109 461 62.75 410 63 384C63 384 59.25 323.5 212.125 264.875ZM245.375 279.375C245.375 279.375 272.125 279.125 272.125 250.125C272 250 271 227 244 226C244 226 218.625 226.75 218.625 253.75C218.625 253.75 223.625 281.375 245.625 279.375Z";
	public static final String s=
			"M50 98C50 98 98 98 98 48C98 48 96 2 48 2C48 2 4 2 2 49C2 49 2 98 50 98ZM678 140M48 98C48 98 73 99 72 73C72 73 72 51 51 50C51 50 27.75 49.25 26.75 27.25C27 27 27 2.5 47.25 2.5M51 81C51 81 55 81 55 77C55 77 55 73.25 51 73.25C48 74 48 77 48 77C48 77 48 80 51 81ZM50 23C50 23 54.375 22.25 54.375 27.25C54 27 54 31 51 31C51 31 46 31 46 27C46 27 46 23 50 23Z";
	public static final String STUDIO_PATH = 
        " M 52.94,25.99" +
                "        C 54.70,27.18 58.25,30.92 55.38,32.87" +
                "         53.64,34.06 50.66,32.48 49.00,31.77" +
                "        44.56,29.85 41.99,28.75 37.00,29.10" +
                "       21.36,30.18 13.70,48.56 19.53,62.00" +
                "      22.50,68.84 29.26,74.19 37.00,73.61" +
                "     43.33,73.14 49.81,67.04 51.26,72.12" +
                "    53.13,78.70 37.87,80.08 34.00,79.99" +
                "   10.19,79.41 4.28,49.79 15.91,33.01" +
                "  20.95,25.75 27.76,23.69 36.00,22.47" +
                " 41.00,22.20 48.74,23.14 52.94,25.99 Z" +
                "M 85.00,65.84" +
                "C 82.53,65.59 79.75,64.73 77.70,66.61" +
                "                   75.27,68.83 75.05,73.95 73.74,76.87" +
                "                 72.86,78.84 70.77,80.74 68.62,78.96" +
                "                66.15,76.91 69.13,66.86 69.88,64.00" +
                "                 73.10,51.79 81.15,32.08 92.00,25.13" +
                "                 101.45,19.08 109.84,24.43 115.07,33.00" +
                "                 123.63,47.03 124.00,64.11 124.00,80.00" +
                "                 124.00,80.00 118.00,80.00 118.00,80.00" +
                "                 116.91,66.50 116.29,52.54 110.56,40.00" +
                "                     108.74,36.03 104.10,29.12 99.00,29.92" +
                "                    95.93,30.41 92.89,33.75 91.02,36.04" +
                "                   85.37,42.92 82.99,50.32 79.00,58.00" +
                "                  79.00,58.00 101.00,61.00 101.00,61.00" +
                "                 101.00,61.00 101.00,67.00 101.00,67.00" +
                "                101.00,67.00 85.00,65.84 85.00,65.84 Z" +
                "             M 194.00,29.19" +
                "            C 186.00,28.52 174.79,34.08 182.15,41.82" +
                "             191.33,51.47 211.73,49.31 210.95,67.00" +
                "            210.84,69.53 210.42,71.74 208.99,73.90" +
                "           204.24,81.09 189.05,81.53 182.00,78.18" +
                "          179.10,76.79 171.54,72.44 173.40,68.17" +
                "         174.53,65.82 177.29,67.08 179.00,68.17" +
                "        185.34,71.43 191.43,76.47 198.96,71.91" +
                "       201.68,70.27 204.10,67.40 203.16,64.01" +
                "      202.29,60.89 198.73,58.40 196.00,56.99" +
                "     189.29,53.53 181.83,52.45 176.11,46.82" +
                "    168.81,39.64 171.52,27.88 181.00,24.15" +
                "   183.02,23.35 188.73,22.50 191.00,22.32" +
                "  196.86,21.88 213.98,26.44 216.98,31.53" +
                "                     218.05,33.37 217.41,35.10 216.98,37.00" +
                "                    208.71,35.44 202.99,29.93 194.00,29.19 Z" +
                "                 M 334.00,23.00" +
                "                C 334.00,23.00 334.00,80.00 334.00,80.00" +
                "                 327.17,79.76 327.04,78.59 327.00,72.00" +
                "                327.00,72.00 327.00,23.00 327.00,23.00" +
                "               327.00,23.00 334.00,23.00 334.00,23.00 Z" +
                "            M 347.06,30.87" +
                "           C 346.18,30.48 345.28,30.03 344.61,29.30" +
                "            338.92,23.07 353.17,20.85 352.45,28.11" +
                "           352.31,29.52 351.57,30.74 351.00,32.00" +
                "          351.00,32.00 347.06,30.87 347.06,30.87 Z" +
                "          M 239.00,25.00" +
                "                  C 239.00,25.00 238.00,44.00 238.00,44.00" +
                "                   238.00,44.00 250.00,45.00 250.00,45.00" +
                "                  250.00,45.00 250.00,50.00 250.00,50.00" +
                "                 250.00,50.00 237.00,51.00 237.00,51.00" +
                "                237.00,51.00 236.00,73.00 236.00,73.00" +
                "               236.00,73.00 246.00,73.00 246.00,73.00" +
                "              245.87,74.55 245.94,76.15 244.98,77.49" +
                "             242.28,81.27 232.54,80.85 230.05,76.85" +
                "            227.81,72.85 229.77,65.49 230.05,61.00" +
                "           230.05,61.00 230.05,51.00 230.05,51.00" +
                "          230.05,51.00 222.00,50.00 222.00,50.00" +
                "         222.00,50.00 222.00,44.00 222.00,44.00" +
                "        222.00,44.00 231.00,44.00 231.00,44.00" +
                "       231.00,44.00 232.00,25.00 232.00,25.00" +
                "      232.00,25.00 239.00,25.00 239.00,25.00 Z" +
                "           M 375.01,50.93" +
                "          C 367.97,53.77 365.02,62.63 369.65,68.96" +
                "           371.32,71.23 373.27,72.80 376.00,73.57" +
                "          378.27,74.21 381.60,73.71 382.92,75.58" +
                "         384.61,77.98 382.01,79.51 379.94,79.85" +
                "        355.41,83.96 352.61,44.85 378.00,43.38" +
                "       381.85,43.15 384.63,44.37 388.00,46.00" +
                "      388.00,46.00 386.00,50.93 386.00,50.93" +
                "     382.42,50.36 378.53,49.40 375.01,50.93 Z" +
                "  M 279.00,78.43" +
                " C 272.66,81.45 262.18,80.74 257.65,74.90" +
                "                      252.71,68.53 253.88,60.33 255.26,53.00" +
                "                     255.68,50.77 256.44,46.36 258.49,45.08" +
                "                    262.14,42.80 262.82,47.61 262.54,50.00" +
                "                     261.69,57.42 258.00,67.08 266.04,72.15" +
                "                    268.57,73.73 271.17,73.97 274.00,73.19" +
                "                   284.79,70.22 282.75,64.58 282.00,56.00" +
                "                  281.34,48.41 278.98,44.67 287.00,44.00" +
                "                 289.09,55.48 291.00,67.32 291.00,79.00" +
                "                291.00,79.00 286.00,80.00 286.00,80.00" +
                "               286.00,80.00 285.00,74.00 285.00,74.00" +
                "              282.98,75.79 281.49,77.24 279.00,78.43 Z" +
                "           M 300.34,75.61" +
                "          C 291.97,67.57 294.53,48.75 306.00,44.93" +
                "           309.31,43.73 316.74,43.59 319.94,44.93" +
                "          321.95,45.90 325.17,48.93 322.38,50.70" +
                "         320.63,52.12 316.99,50.75 315.00,50.70" +
                "        310.70,49.97 307.22,51.44 304.72,55.05" +
                "       300.58,61.03 302.62,70.44 310.00,72.65" +
                "      314.01,73.85 318.21,72.24 322.00,71.00" +
                "     322.00,71.00 324.00,77.00 324.00,77.00" +
                "    316.55,80.49 306.92,81.93 300.34,75.61 Z" +
                " M 351.00,44.00" +
                "C 351.00,44.00 351.00,80.00 351.00,80.00" +
                "                     351.00,80.00 344.00,80.00 344.00,80.00" +
                "                    344.00,80.00 344.00,44.00 344.00,44.00" +
                "                   344.00,44.00 351.00,44.00 351.00,44.00 Z" +
                "                M 390.26,65.00" +
                "               C 392.40,59.05 387.17,54.61 389.13,51.37" +
                "                391.39,47.61 395.25,52.94 396.20,55.00" +
                "               400.41,64.18 396.64,73.71 387.00,77.00" +
                "              384.80,69.52 388.16,70.84 390.26,65.00 Z" +
                "           M 62.00,52.00" +
                "          C 62.00,52.00 61.09,70.00 61.09,70.00" +
                "           61.09,70.00 59.98,78.40 59.98,78.40" +
                "          59.98,78.40 55.00,80.00 55.00,80.00" +
                "         55.00,75.85 56.03,61.31 53.40,58.74" +
                "        51.44,56.82 38.73,56.49 35.00,56.00" +
                "       35.00,56.00 35.00,50.00 35.00,50.00" +
                "      35.00,50.00 62.00,52.00 62.00,52.00 Z" +
                "   M 169.00,89.00" +
                "  C 169.00,89.00 169.00,96.00 169.00,96.00" +
                "   169.00,96.00 126.00,96.00 126.00,96.00" +
                "  126.00,96.00 126.00,89.00 126.00,89.00" +
                " 126.00,89.00 169.00,89.00 169.00,89.00 Z"
;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.fragment_main);
		 final SvgView svg=(SvgView) findViewById(R.id.svg);
		 View svgd= findViewById(R.id.svgd);
		 Button restart=(Button) findViewById(R.id.restart);
		 final ImageView animationIV=(ImageView) findViewById(R.id.animationIV);
		final TextView text=(TextView) findViewById(R.id.text);
		text.setText("进度: 00.0"+"%"+"         已用时："+"    总时长："+"  s");
		//svg.animate().translationXBy(100).setDuration(2*1000).start();
		svg.setSvgData(svgs);
		
		svg.setGravity(Gravity.CENTER);
		//svg.getMatrix().postTranslate(-7, -17);
		svg.sesScaleType(ScaleType.FIT_XY);
		svg.getPaint().setColor(Color.RED);
		//svg.getPaint().setStyle(Style.FILL);
		//int num=svg.getPahtNum();		
		final ObjectAnimator animator=ObjectAnimator.ofFloat(svg, "progress", svg.getLength());
		animator.setDuration(4*1000);
		animator.setInterpolator(new LinearInterpolator());
		animator.addUpdateListener(new AnimatorUpdateListener() {
			
			@Override
			public void onAnimationUpdate(ValueAnimator animation) {
				float percent=((Float)animation.getAnimatedValue())/svg.getLength();
				DecimalFormat format=new DecimalFormat("#0.0");
				text.setText("进度: "+format.format(percent*100)+"%"+"         已用时："+(int)(animation.getCurrentPlayTime()/1000)+"s"+"  总时长："+(int)(animation.getDuration()/1000)+"s");
				
			}
		});
		restart.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				animator.start();
			}
		});
		animator.addListener(new AnimatorListener() {
			
			@Override
			public void onAnimationStart(Animator animation) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationRepeat(Animator animation) {
				// TODO Auto-generated method stub
				
			}
			
			@SuppressLint("NewApi")
			@Override
			public void onAnimationEnd(Animator animation) {
				//rotation(svg, 3, 9*1000);
				//animationIV.setVisibility(View.VISIBLE);
				/*svg.animate().alpha(0).setDuration(500).start();
				animationIV.animate().alpha(1).setDuration(500).withEndAction(new Runnable() {
					 
					@Override
					public void run() {
						animationIV.animate().rotation(-360*10000).setInterpolator(new LinearInterpolator()).setDuration(1000*10000).start();
						
					}
				}).start();*/
				//AnimationDrawable draw=(AnimationDrawable) animationIV.getDrawable();
			//	draw.start();
			}
			
			@Override
			public void onAnimationCancel(Animator animation) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}

	public void rotation(View v,int x,long duration)
	{
		v.setPivotX(v.getWidth()/2);
		v.setPivotY(v.getHeight()/2);
		//v.animate().translationXBy(100).setDuration(2*1000).start();
		v.animate().rotationY(x*360).setDuration(duration).start();
	}

}
