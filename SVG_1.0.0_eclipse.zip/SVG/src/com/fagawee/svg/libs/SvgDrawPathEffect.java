package com.fagawee.svg.libs;

public class SvgDrawPathEffect {

}
