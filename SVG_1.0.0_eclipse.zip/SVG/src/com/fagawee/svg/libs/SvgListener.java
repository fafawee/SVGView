package com.fagawee.svg.libs;

public interface SvgListener {

}
