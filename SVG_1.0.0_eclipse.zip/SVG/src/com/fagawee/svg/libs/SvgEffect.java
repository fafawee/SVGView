package com.fagawee.svg.libs;

import android.graphics.Canvas;

public interface SvgEffect {

	void onDraw(Canvas canvas ,float position);
}
