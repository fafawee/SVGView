package com.fagawee.svg.libs;

public class SvgDrawable {

}
